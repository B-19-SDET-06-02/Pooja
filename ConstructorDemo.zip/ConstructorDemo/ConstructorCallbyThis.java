package ConstructorDemo;

public class ConstructorCallbyThis {
	public ConstructorCallbyThis() 
	{
		this(10); // constructor calling by this keyword
		System.out.println("Hello java");
	}
	public ConstructorCallbyThis(int num1)
	{
		System.out.println(num1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorCallbyThis ch=new ConstructorCallbyThis();

	}

}
