package ConstructorDemo;

public class ConstructorOverloading {
	double radius;
	public ConstructorOverloading(double radius)//parameterized constructor
	{
		this.radius=radius;
	}
	public ConstructorOverloading() //constructor overloading
	{
		this(1.0);
	}
//	public double getArea() //creating method type of take nothing return something
//	{
//		return this.radius * this.radius * Math.E;
//	}
	public void getArea() // create method type of take nothing return nothing
	{
		double r=this.radius * this.radius * Math.PI;
		System.out.println(r);
	}
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorOverloading obj=new ConstructorOverloading();
		//double r=obj.getArea();
		//System.out.println(r);
		obj.getArea();

	}

}
