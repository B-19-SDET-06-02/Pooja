package ConstructorDemo;

public class ParameterizedConstructor {
	int num1,num2;
	public ParameterizedConstructor(int num1,int num2) //paramerterized constructor
	{
		System.out.println(num1+" "+num2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParameterizedConstructor oo=new ParameterizedConstructor(150, 250);

	}

}
