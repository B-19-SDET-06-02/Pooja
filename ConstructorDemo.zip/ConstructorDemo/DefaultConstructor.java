package ConstructorDemo;

public class DefaultConstructor {
	int num=100;
	public DefaultConstructor() //default constructor
	{
		System.out.println(num);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultConstructor dc=new DefaultConstructor();

	}

}
