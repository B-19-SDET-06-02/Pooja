package ConstructorDemo;

public class thisKeywordCallMethod {
	int num1,num2,res;
	public void acc()
	{
		num1=234;
		num2=345;
		res=num1+num2;
		System.out.println(res);
		this.check();
	}
	public void check()
	{
		System.out.println("Hello java");
		//this.acc();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		thisKeywordCallMethod th=new thisKeywordCallMethod();
		th.acc();

	}

}
