package ConstructorDemo;

public class thisKeyword {
	int num1;
	public thisKeyword(int num1)// parameterized constructor
	{
		this.num1=num1;
		System.out.println("Num1:"+ num1);// w/o this keyword print 194
		//System.out.println("Num1:"+this.num1); // with this keyword print 100
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		thisKeyword oo=new thisKeyword(194);

	}

}
