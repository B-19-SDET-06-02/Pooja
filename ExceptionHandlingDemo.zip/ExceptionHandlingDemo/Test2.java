package ExceptionHandlingDemo;

public class Test2 {
	public static void acc()
	{
		try
		{
			int x=0;
			int y=5/x;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("exception");
		}
		catch(ArithmeticException e1)
		{
			System.out.println("arithmetic exception");
			System.out.println("finished");
		}
		finally
		{
			System.out.println("finished");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		acc();
	}

}
