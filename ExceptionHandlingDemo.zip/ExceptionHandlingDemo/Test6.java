package ExceptionHandlingDemo;

import javax.management.RuntimeErrorException;

public class Test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			badmethod();
			System.out.println("A");
		}
		catch(RuntimeException ee)
		{
			System.out.println("B");
		}
		catch(Exception er)
		{
			System.out.println("C");
		}
		finally
		{
			System.out.println("D");
		}
		System.out.println("E");

	}
		public static void badmethod()
		{
			throw new RuntimeException();
		}
}
