package ExceptionHandlingDemo;



public class TryCatchDemo {
//	int a=50/0;
//	public  void acc()
//	{
//		int a=50/0;
//	}
	public void disp()
	{
		try
		{
			int a=50/0;		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("Enter another number except zero");
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		TryCatchDemo oo=new TryCatchDemo();
		oo.disp();
		//System.out.println("Normal Flow");
		

	}

}
