package ExceptionHandlingDemo;

public class TestTryCatch {

		  void m()
		  {  
		    int data=50/0;  
		  }  
//		  void n()
//		  {  
//		    m();  
//		  }  
	  void p()
		  {  
			  try
			  {  
				  m();  
			  }
			  catch(Exception e)
			  {
				  System.out.println("exception handled");
			  }  
		  }  
		  public static void main(String args[]){  
			  TestTryCatch obj=new TestTryCatch();  
		   obj.p();  
		   System.out.println("normal flow...");  
		  }  
		}  
