package ExceptionHandlingDemo;

public class Test1 {
	public static void aMethod()throws Exception
	{
		try
		{
			throw new Exception();
		}
		finally
		{
			System.out.println("Finally");
		}
	}

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		try
		{
		aMethod();
		}
		catch(Exception e)
		{
			System.out.println("exception");
		}
		System.out.println("finished");

	}

}
