package ExceptionHandlingDemo;

public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			badmethod();
			System.out.println("A");
		}
		catch(Exception er)
		{
			System.out.println("B");
		}
		finally
		{
			System.out.println("C");
		}
		System.out.println("D");

	}
	public static void badmethod()
	{
		throw new RuntimeException();
	}

}
