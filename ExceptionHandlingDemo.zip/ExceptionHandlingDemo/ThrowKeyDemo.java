package ExceptionHandlingDemo;

import java.util.Scanner;

public class ThrowKeyDemo {
//	Scanner sc=new Scanner(System.in);
//	int age;
	public void acc(int age)
	{
		if(age <18)
		{
			//System.out.println("sorry you cannot vote");
			throw new ArithmeticException("sorry you cannot vote");
		}
		else
		{
			System.out.println("Yes,You have right to vote");
		}
		
//	try
//		{
//		
//			System.out.println("Enter age");
//			age=sc.nextInt();
//			if(age<18)
//			{
//			//throw new ArithmeticException("Not valid");
//				System.out.println("not valid");
//			
//			}
//		}
//	catch(Exception e)
//	{
//			System.out.println("Yes you can vote");
//	}
	}

	public static void main(String[] args){
		// TODO Auto-generated method stub
		ThrowKeyDemo oo=new ThrowKeyDemo();
		oo.acc(20);
	}

}
