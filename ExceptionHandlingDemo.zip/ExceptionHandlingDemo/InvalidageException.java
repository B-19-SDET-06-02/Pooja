package ExceptionHandlingDemo;

public class InvalidageException extends Exception {
	InvalidageException(String s){
	super(s);
	
}
}
