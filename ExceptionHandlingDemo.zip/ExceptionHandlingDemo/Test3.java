package ExceptionHandlingDemo;

public class Test3 {
//	public static int res()
//	{
//		try
//		{
//			return 0;
//		}
//		finally
//		{
//			System.out.println("fnally");
//		}
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			return ;
		}
		finally
		{
			System.out.println("fnally");
		}
	}

}
