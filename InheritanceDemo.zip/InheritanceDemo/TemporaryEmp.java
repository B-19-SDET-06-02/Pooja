package InheritanceDemo;

public class TemporaryEmp extends PermanentEmp{
	void calculate_balance_leave() // Override method
	{
		calculate_salary();
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TemporaryEmp tmp=new TemporaryEmp();
		tmp.calculate_balance_leave();

	}

}
