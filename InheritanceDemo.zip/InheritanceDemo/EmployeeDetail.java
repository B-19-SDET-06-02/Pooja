package InheritanceDemo;

import java.util.Scanner;

public class EmployeeDetail {
	int empId;
	String empName;
	int Total_leaves;
	double Total_salary;
	Scanner sc=new Scanner(System.in);
	void calculate_balance_leaves()
	{
		System.out.println("Enter Employee Id");
		empId=sc.nextInt();
		
		System.out.println("Enter Employee name");
		empName=sc.next();
		
		System.out.println("Enter total salary");
		Total_salary=sc.nextDouble();
		
		System.out.println("Enter total leaves");
		Total_leaves=sc.nextInt();
	}
//	boolean avail_leave(boolean no_of_leaves,char type_of_leaves)
//	{
//		return no_of_leaves;
//	}
	void calculate_salary()
	{
		System.out.println("Employee Id is:"+empId);
		System.out.println("Employee Name is:"+empName);
		System.out.println("Total leaves are:"+Total_leaves);
		System.out.println("Total salary is:"+Total_salary);
	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
