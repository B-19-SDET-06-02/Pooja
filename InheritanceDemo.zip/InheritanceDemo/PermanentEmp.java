package InheritanceDemo;

public class PermanentEmp extends EmployeeDetail{
	int paid_leave,sick_leave,casual_leave;
	double basic,hra,pfa;
	
	void print_leave_details()
	{
		super.calculate_balance_leaves();
		
		System.out.println("Enter paid leave");
		paid_leave=sc.nextInt();
		
		System.out.println("Enter sick_leave");
		sick_leave=sc.nextInt();
		
		System.out.println("Enter casual leave");
		casual_leave=sc.nextInt();
		
		super.calculate_salary();
	}
	void calculate_balance_leaves() //Override method
	{
		
		System.out.println("Enter basic salary");
		basic=sc.nextDouble();
		
		System.out.println("Enter hra");
		hra=sc.nextDouble();
		
		System.out.println("Enter pfa");
		pfa=sc.nextDouble();
	}
//	boolean avail_balance(boolean no_of_leaves,char type_of_leaves) // Override method
//	{
//		return no_of_leaves;
//	}
	void calculate_salary()
	{
		System.out.println("Paid leave is:"+paid_leave);
		System.out.println("Sick leave is:"+sick_leave);
		System.out.println("Casual leave is:"+casual_leave);
		System.out.println("Basic salary is:"+basic);
		System.out.println("Hra is:"+hra);
		System.out.println("Pfa is:"+pfa);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PermanentEmp obj=new PermanentEmp();
		obj.print_leave_details();
		obj.calculate_balance_leaves();
		obj.calculate_salary();
		
	}

}
