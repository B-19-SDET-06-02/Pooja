package InheritanceDemo;

import java.util.Scanner;

public class SingleInheritDemo { // Base class or Super Class or parent class
	//Default access specifiers
	int rollno; 
	String name;
	long contact;
	Scanner sc=new Scanner(System.in); // to get input from user, use scanner class
	
	public void acc()
	{
		System.out.println("Enter Rollno");
		rollno=sc.nextInt();
		
		System.out.println("Enter Name");
		name=sc.next();
		
		System.out.println("Enter Contact No");
		contact=sc.nextLong();
	}
	public void display()
	{
		System.out.println("RollNo is:"+rollno);
		System.out.println("Name is:"+name);
		System.out.println("Contact No is:"+contact);
	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
