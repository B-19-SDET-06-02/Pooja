package InheritanceDemo;

public class DerivedbaseDemo extends SingleInheritDemo{
	int hindi,eng,math,sci;
	public void access()
	{
		acc();
		System.out.println("Enter Hindi marks");
		hindi=sc.nextInt();
		
		System.out.println("Enter english marks");
		eng=sc.nextInt();
		
		System.out.println("Enter math marks");
		math=sc.nextInt();
		
		System.out.println("Enter Science marks");
		sci=sc.nextInt();
		
		display();
	}
	public void displaydet()
	{
		System.out.println("Marks in Hindi:"+hindi);
		System.out.println("Marks in English:"+eng);
		System.out.println("Marks in Maths:"+math);
		System.out.println("Marks in Science:"+sci);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DerivedbaseDemo dv=new DerivedbaseDemo();
		dv.access();
		dv.displaydet();
		

	}

}
