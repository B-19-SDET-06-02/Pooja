package MethodsDemo;

public class TSRSDemo {
	int a,b;
	//Take Something Return Something
public int acc(int a,int b) // taking input
{
	return a+b; //returning output
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TSRSDemo oo=new TSRSDemo();
		int c=oo.acc(10,20);
		System.out.println(c);

	}

}
