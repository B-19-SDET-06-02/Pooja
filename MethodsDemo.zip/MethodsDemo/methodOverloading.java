package MethodsDemo;

public class methodOverloading {
	int num1,num2,res;
	public void add()
	{
		num1=234;
		num2=123;
		res=num1+num2;
	}
	public void acc()
	{
		add();
		System.out.println(res);
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methodOverloading oo=new methodOverloading();
		oo.acc();

	}

}
