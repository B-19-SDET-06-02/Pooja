package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class EmployeeDetail {
	public void accept()
	{
		ArrayList<EmployDetail> ac=new ArrayList<EmployDetail>();
		System.out.println("Employee Details are as following");
		ac.add(new EmployDetail(01,"pooja",17.07,25000,'A'));
		ac.add(new EmployDetail(02, "mansi",01.07,25000,'A'));
		ac.add(new EmployDetail(03, "manav", 10.08, 25000, 'A'));
		ac.add(new EmployDetail(04, "pushkar", 10.07, 25000, 'A'));
		ac.add(new EmployDetail(03, "mansi", 19.07, 25000, 'B'));
		ac.add(0,new EmployDetail(05, "Kulveer", 10.08, 25000, 'A'));//Add new array list at 0th position
		System.out.println("Traversing through iterator");
		// Getting employ detail using Iterator
		Iterator<EmployDetail> itr= ac.iterator();
		while(itr.hasNext())
		{
			EmployDetail e2=(EmployDetail)itr.next();
			System.out.println(e2.empId+" "+e2.empName+" "+e2.DOJ+" "+e2.grade+" "+e2.Salary);
		}
		// Getting employ detail using ForEach loop
		System.out.println("Traversing through foreacj loop");
		for(EmployDetail e:ac)
		{
			//System.out.println("Employee Details are as following");
			System.out.println(e.empId +" "+e.empName+" "+e.DOJ+" "+e.grade+" "+e.Salary);
			
		}
		// Delete array list from Index 1 using forEach Loop
		ac.remove(1);
		System.out.println("Remove employ details from Index 1");
		for(EmployDetail e1:ac)
		{
			System.out.println(e1.empId+" "+e1.empName+" "+e1.DOJ+" "+e1.grade+" "+e1.Salary);
		}
	}
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDetail oo=new EmployeeDetail();
		oo.accept();

	}

}
