package CollectionDemo;

import java.util.HashMap;
import java.util.Map;

public class MapInterfaceDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Student Details
		Map<Integer,String> st=new HashMap<Integer,String>();
		System.out.println("/*Student Detail*/");
		st.put(01, "Pooja");
		st.put(02, "Pushkar");
		st.put(03, "Raj");
		st.put(04, "Kulveer");
		for(Map.Entry m:st.entrySet())
		{
			System.out.println(m.getKey() +" "+ m.getValue());
		}
		// Teacher detail
		Map<Integer,String> tc=new HashMap<Integer,String>();
		System.out.println("/*Teacher Detail*/");
		tc.put(01, "Sampada");
		tc.put(02, "Shweta");
		tc.put(03, "Shruti");
		tc.put(04,"Shikhi");
		for(Map.Entry m1:tc.entrySet())
		{
			System.out.println(m1.getKey() +""+m1.getValue());
		}
		
		
		

	}

}
