package CollectionDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayListDemo {
	public void accept()
	{
		ArrayList<Object> al=new ArrayList<Object>();// generic Array list
		//ArrayList al=new ArrayList();// non-generic Array list
		
		al.add(01);
		al.add("Pooja");
		al.add(7837488919l);
		al.add(89.99f);
		al.add(80.99);
		System.out.println(al);
		System.out.println("Size of arraylist is:"+al.size());
		System.out.println("Index of Pooja is:"+al.indexOf("Pooja"));
		al.remove(2);// only remove the element
		//System.out.println(al.remove(2));//remove the element as well as it print the removed element
		//System.out.println(al);
//		Iterator it=al.iterator();// using iterator as loop
//		while(it.hasNext())
//		{
//			System.out.println(it.next());
//		}
//		for(Object Obj:al)
//		{
//			System.out.println(Obj);
//		}
		for(int i=0;i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		// Using List Iterator to print array list
		System.out.println("Through List Iterator");
		ListIterator<Object> lst=al.listIterator(al.size());
		while(lst.hasPrevious())
		{
			Object ab=lst.previous();
			System.out.println(ab);
		}
		  System.out.println("Traversing list through forEach() method:");  
	        //The forEach() method is a new feature, introduced in Java 8.  
	            al.forEach(a->{ //Here, we are using lambda expression  
	                System.out.println(a);  
	              });  
	            System.out.println("Traversing list through forEachRemaining() method:");  
	              Iterator<Object> itr=al.iterator();  
	              itr.forEachRemaining(a-> //Here, we are using lambda expression  
	              {  
	            System.out.println(a);  
	              }); 
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListDemo oo=new ArrayListDemo();
		oo.accept();

	}

}
