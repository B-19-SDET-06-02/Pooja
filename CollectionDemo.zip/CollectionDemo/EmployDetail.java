package CollectionDemo;

public class EmployDetail {
	int empId;
	String empName;
	double DOJ;
	float Salary;
	char grade;
	
	
	
	public EmployDetail(int empId,String empName,double DOJ,float Salary,char grade)
	{
		this.empId=empId;
		this.empName=empName;
		this.DOJ=DOJ;
		this.Salary=Salary;
		this.grade=grade;
	}

}
