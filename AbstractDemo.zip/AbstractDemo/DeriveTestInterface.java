package AbstractDemo;

public class DeriveTestInterface implements Testinterface2{
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeriveTestInterface oo=new DeriveTestInterface();
	oo.acc();
	oo.print();
	oo.show();
	oo.display();
	System.out.println(Testinterface2.cube(5));

	}

	@Override
	public void acc() {
		// TODO Auto-generated method stub
		System.out.println("class implements interface");
		System.out.println("class extends class");
		System.out.println("interface extends interface");
		
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Data members are public static & final by default");
		System.out.println("Methods in interface are public & static by default");
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("multiple inheritance");
		
	}

}
