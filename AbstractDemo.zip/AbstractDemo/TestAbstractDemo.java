package AbstractDemo;

abstract class TestAbstractDemo {
	int a;
	static int b;
	abstract int acc();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
