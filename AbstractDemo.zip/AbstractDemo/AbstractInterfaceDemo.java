package AbstractDemo;

interface AbstractInterfaceDemo {
	void a();
	void b();
	void c();
	void d();
}
abstract class dem implements AbstractInterfaceDemo
{
//	public void c()
//	{
//		System.out.println("I am c");
//	}
}
class de extends dem
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		de oo=new de();
		oo.a();
		oo.b();
		oo.c();
		oo.d();
	}

	@Override
	public void a() {
		// TODO Auto-generated method stub
		System.out.println("I am a");
		
	}

	@Override
	public void b() {
		// TODO Auto-generated method stub
		System.out.println("I am b");
	}

	@Override
	public void d() {
		// TODO Auto-generated method stub
		System.out.println("I am D");
	}

	@Override
	public void c() {
		// TODO Auto-generated method stub
		System.out.println("I am C");
	}

}
