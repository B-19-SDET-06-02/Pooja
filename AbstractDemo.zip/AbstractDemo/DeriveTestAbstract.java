package AbstractDemo;

public class DeriveTestAbstract extends TestAbstractDemo{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DeriveTestAbstract oo=new DeriveTestAbstract();
		System.out.println(oo.acc());

	}

	@Override
	int acc() {
		int a=10;
		return a;
	}

}
