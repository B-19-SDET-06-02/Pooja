package AbstractDemo;

interface TestinterfaceDemo {
	int a=5;
	void acc();
	void print();
}
interface Testinterface2 extends TestinterfaceDemo{
	void show();
	default void display()
	{
		System.out.println("Can also create default method with body in interface");
	}
	static int cube(int a)
	{
		return a*a*a;
	}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
