package StringBuffer;

public class AppnedDemo {
 StringBuffer st =new StringBuffer("Pooja");
 public void app()
 {
	 StringBuffer st1=st.append(" " +"Garg");
	 System.out.println(st1);
 }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AppnedDemo oo=new AppnedDemo();
		oo.app();
		

	}

}
