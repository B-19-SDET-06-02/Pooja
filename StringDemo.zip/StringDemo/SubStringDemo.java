package StringDemo;

public class SubStringDemo {
	String st="Hello Java World";
	public void sbt()
	{
		String str=st.substring(2,7); //Substring starts from l and goes to J
		System.out.println(str);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubStringDemo oo=new SubStringDemo();
		oo.sbt();

	}

}
