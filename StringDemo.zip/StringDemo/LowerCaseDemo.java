package StringDemo;

public class LowerCaseDemo {
	String s1="SHE IS A SINCERE GIRL";
	public void lwr()
	{
		String s2=s1.toLowerCase();
		System.out.println(s2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LowerCaseDemo oo=new LowerCaseDemo();
		oo.lwr();

	}

}
