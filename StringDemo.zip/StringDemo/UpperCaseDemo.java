package StringDemo;

public class UpperCaseDemo {
	String a="hello  java";
	public void upr()
	{
		String b=a.toUpperCase();
		System.out.println(b);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UpperCaseDemo oo=new UpperCaseDemo();
		oo.upr();

	}

}
