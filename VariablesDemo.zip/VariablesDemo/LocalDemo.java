package VariablesDemo;

public class LocalDemo {
	public void lc()
	{
		int a=90;  //Local variables
		System.out.println(a); 
	}
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDemo oo=new LocalDemo();
		oo.lc();

	}

}
