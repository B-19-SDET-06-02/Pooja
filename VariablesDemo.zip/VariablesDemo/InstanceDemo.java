package VariablesDemo;

public class InstanceDemo {
	int a=50; //Instance variable
	int b=30; //Instance variable
	int c;
	public void ins()
	{
		c=a+b;
		System.out.println("Addition of two numbers:"+c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InstanceDemo oo=new InstanceDemo();
		oo.ins();
		

	}

}
