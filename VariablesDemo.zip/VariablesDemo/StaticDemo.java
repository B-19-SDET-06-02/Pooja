package VariablesDemo;

public class StaticDemo{

	static int a=100;  //Static Variables
	
//	public void std()
//	{
//		System.out.println(a);
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		StaticDemo oo=new StaticDemo();
//		oo.std();
		System.out.println(a); //Direct calling of Static variables
	
		
	}

}
