package ArrayDemo;

public class Searchary {
	int a[]= {11,23,45,67,89,34,65,84};
	public void srch()
	{
		System.out.println("Search element on array");
		for(int i=0;i<=0;i++)
		{
			System.out.println(a[5]);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Searchary sc=new Searchary();
		sc.srch();

	}

}
