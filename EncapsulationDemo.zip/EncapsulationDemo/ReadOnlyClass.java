package EncapsulationDemo;

public class ReadOnlyClass {
	private String college="D.A.V";
	public String getCollege()
	{
		return college;
	}
//	public void setCollege(String college)
//	{
//		this.college=college;
//	}
}

