package EncapsulationDemo;

public class DeriveTestEncaps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestEncapsulation oo=new TestEncapsulation();
		oo.setstDet(101);
		System.out.println(oo.getRollno());
		oo.setName("pooja");
		System.out.println(oo.getName());
		oo.setContact(7837488919l);
		System.out.println(oo.getContact());
		oo.setMarks(78.80f);
		System.out.println(oo.getMarks());
		

	}

}
