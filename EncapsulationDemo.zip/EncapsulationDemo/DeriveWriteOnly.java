package EncapsulationDemo;

public class DeriveWriteOnly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WriteOnlyDemo oo=new WriteOnlyDemo();
		oo.setCollege("D.A.V");
		//System.out.println(oo.getCollege());

	}

}
