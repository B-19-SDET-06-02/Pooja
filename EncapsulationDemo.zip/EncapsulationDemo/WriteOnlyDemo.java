package EncapsulationDemo;

public class WriteOnlyDemo {
	private String college;
	public void setCollege(String college)
	{
		this.college=college;
	}
}
