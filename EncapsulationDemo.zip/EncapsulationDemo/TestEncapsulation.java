package EncapsulationDemo;

public class TestEncapsulation {
	private int rollno;
	private String name;
	private long contact;
	private float marks;
	public int getRollno()
	{
		return rollno;
	}
	public void setstDet(int rollno)
	{
		this.rollno=rollno;
	} 
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public long getContact()
	{
		return contact;
	}
	public void  setContact(long contact)
	{
		this.contact=contact;
	}
	public float getMarks()
	{
		return marks;
	}
	public void setMarks(float marks)
	{
		this.marks=marks;
	}
}
