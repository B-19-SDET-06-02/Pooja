package EncapsulationDemo;

public class DeriveReadOnly {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				ReadOnlyClass oo=new ReadOnlyClass();
				//oo.setCollege("G.S.D");
				System.out.println(oo.getCollege());
			}
		

	}


