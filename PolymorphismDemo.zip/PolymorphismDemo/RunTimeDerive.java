package PolymorphismDemo;

public class RunTimeDerive extends RunTimeBase {
	public int acc(int a, int b)
	{
		return a-b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunTimeDerive obj=new RunTimeDerive();
		System.out.println(obj.acc(20,10));
		RunTimeBase oo=new RunTimeBase();
		System.out.println(oo.acc(30,30));

	}

}
