package PolymorphismDemo;

public class FinalMethodInherit extends FinalMethodBase{
	public int sub(int a,int b)
	{
		return a-b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalMethodInherit obj=new FinalMethodInherit();
		System.out.println(obj.add(20, 50));
		System.out.println(obj.sub(50, 30));

	}

}
