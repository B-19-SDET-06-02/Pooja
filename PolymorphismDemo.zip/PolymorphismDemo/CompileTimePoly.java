package PolymorphismDemo;

public class CompileTimePoly {
	public void add(int a)
	{
	//	a=10;
		System.out.println(a);
	}
//	public void add(int a, int b) // method overloading or compile time polymophism
//	{
////		a=10;
////		b=20;
//		System.out.println(a +" "+b);
//	}
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		CompileTimePoly oo=new CompileTimePoly();
//		oo.add(20);
//		oo.add(20, 30);

	

}
