package PolymorphismDemo;

public class FinalVariableDemo {
	final int speedlimit=90; // final variable
	final void speed()		// final method
	{
		System.out.println("Speedlimit of all vehicles is:"+speedlimit);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalVariableDemo oo=new FinalVariableDemo();
		oo.speed();

	}

}
